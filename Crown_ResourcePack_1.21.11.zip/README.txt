DefiningSMP 2D Crown — Minecraft Java 1.21.11

Pack format: 75 (Minecraft 1.21.11).
Equipment asset: defining:crown

IMPORTANT: your supplied 64x32 image is a crown sprite, not a standard humanoid armor UV texture. This pack includes it as the equipment texture, but the placement on the player head may not look correct until the image is converted to the correct armor UV layout.

The item must also have an equippable component pointing to asset_id defining:crown for the equipment texture to be used.
